﻿
using CsvHelper;
using DemoAPI.Models;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoAPI.BusinessLogic.ClaimsDetail
{
    public class ClaimInformation : IClaimInformation
    {
        public IEnumerable<ClaimsResponse> getAllClaimsByDate(string dateParam)
        {
            var claims = ParserForModels<Claim>("Claim.csv");
            var members = ParserForModels<Member>("Member.csv");

            var result = new List<ClaimsResponse>();

            foreach (var member in members)
            {
                result.Add(new ClaimsResponse()
                {
                    MemberID = member.MemberID,
                    EnrollmentDate = member.EnrollmentDate,
                    FirstName = member.FirstName,
                    LastName = member.LastName,
                    claims = claims.Where(x => DateTime.Parse(x.ClaimDate).Date <= DateTime.Parse(dateParam).Date && x.MemberID == member.MemberID).Select(y => new BaseClaimProperties()
                    {
                        ClaimAmount = y.ClaimAmount,
                        ClaimDate = y.ClaimDate
                    }).ToList()
                });
            }

            return result;


        }

        private IEnumerable<T> ParserForModels<T>(string name)
        {
            var filename = Directory.GetCurrentDirectory() + $"\\Files\\{name}";
            IEnumerable<T> result;
            using (TextReader fileReader = File.OpenText(filename))
            {
                var csv = new CsvReader(fileReader, CultureInfo.InvariantCulture, true);
                result = csv.GetRecords<T>().ToList();
            }
            return result;

        }
    }
}
