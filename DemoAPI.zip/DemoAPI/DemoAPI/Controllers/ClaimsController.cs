﻿using DemoAPI.BusinessLogic.ClaimsDetail;
using DemoAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ClaimsController : ControllerBase
    {
      

        private readonly IClaimInformation _claimInformation;

        public ClaimsController(IClaimInformation claimInformation)
        {
            _claimInformation = claimInformation;
        }

        [HttpGet]
        public IActionResult Get(string dateParam)
        {
            if (string.IsNullOrEmpty( dateParam)) return BadRequest();
           var response = _claimInformation.getAllClaimsByDate(dateParam);
            return Ok(response);

        }
    }
}
