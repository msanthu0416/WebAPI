﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoAPI.Models
{
    public class Claim  : BaseClaimProperties
    {
        public string MemberID { get; set; }
    }


    public class BaseClaimProperties
    {      

        public string ClaimDate { get; set; }
        public string ClaimAmount { get; set; }
    }

}
