﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoAPI.Models
{

   

    public class ClaimsResponse : Member
    {      
        public List<BaseClaimProperties> claims { get; set; }
    }
}
